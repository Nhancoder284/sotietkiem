module.exports = {
    host: 'localhost',
    port: 5432,
    database: 'doan',
    user: 'postgres',
    password: 'nhan',
    max: 30 // use up to 30 connections
};


