$(".savingbook").click(function(e) {
    $(this).children('form').submit();
})
$('form').submit(function (event) {
    
});
